#ifndef POINTERAPP_H
#define POINTERAPP_H

#include "mainwindow.h"
//#include "curvwidget.h"
#include "hismainwin.h"
#include "datathread.h"

//CurvWidget *curvewgt;

HisMainWin *historywin;

MainWindow *mainwin;

DataThread *datathread;

PrintThread *printthread;

#endif // POINTERAPP_H
